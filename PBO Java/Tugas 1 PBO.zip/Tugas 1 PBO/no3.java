public class no3 {
   public static void main(String[] args) {
      double kaki = 22;

      double meters = kaki * 0.3048;
      
      System.out.println(kaki + " kaki = " + meters + " meter");
   }
}