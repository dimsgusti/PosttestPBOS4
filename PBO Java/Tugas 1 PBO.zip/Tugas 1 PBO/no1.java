public class no1{  
    public static void main (String args[])  
     { float Fahrenheit, Celsius;  
            Fahrenheit = 42;
            Celsius  = ((Fahrenheit-32)*5)/9;  
            System.out.println("Temperatur dalam celcius adalah: "+Celsius);  
     }}